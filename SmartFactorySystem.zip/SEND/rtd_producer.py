import pika
import json

# RabbitMQ 연결 설정
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost', 5672))
channel = connection.channel()

# 큐 정의
channel.queue_declare(queue='mcs_queue')

# 테스트용 메시지
test_message = {
    "header": {
        "message_name": "Location_Change",
        "transaction_id": "20240420120000569",
        "system_key": "ACS"
    },
    "body": {
        "equipment_id": "ACS",
        "equipment_unit_id": "unit003",
        "equipment_unit_type": "AGV",
        "location": "1012"
    }
}

# 메시지 전송
channel.basic_publish(exchange='', routing_key='mcs_queue', body=json.dumps(test_message))

print("Message sent!")

# 연결 종료
connection.close()


