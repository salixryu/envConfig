# main.py
from database.database import initialize_engine
from consumer.rtd_consumer import RTDConsumer

def main():
    # MySQL 데이터베이스 초기화
    config_file = 'config.json'
    engine = initialize_engine(config_file)
    
    # RTDConsumer를 사용하여 메시지 수신 시작
    consumer = RTDConsumer(config_file, engine)  # Pass config_file to RTDConsumer
    consumer.start_consuming()

if __name__ == "__main__":
    main()