# location_change.py
from producer.mcs_producer import MCSProducer
from producer.mes_producer import MESProducer

class LocationChange:
    def __init__(self, engine=None):
    # 외부에서 생성된 데이터베이스 연결 사용
        self.engine = engine
    
    def process(self, message):
        print("MCS LocationChange received:")

        # LocationChangeReply 메시지 생성
        location_change_reply_message = {
            "header": {
                "message_name": "Location_Change_Reply",
                "transaction_id": message['header']['transaction_id'],
                "system_key": "RTD"
            },
            "body": message['body'],
            "return": {
                "returncode": "0",
                "returnmessage": "success"
            }
        }

        mcsSender = MCSProducer("config.json")
        mcsSender.send_message(message)
        # mcsSender.send_Reply_message(msg)

        mesSender = MESProducer("config.json")
        mesSender.send_message(message)
        # mesSender.send_Reply_message(msg)
        
