# location_change.py
from producer.mes_producer import MESProducer  # RTDProducer 클래스를 import

class LocationChange:
    def process(self, message):
        print("MES LocationChange received:")
        
        # 메시지 파싱

        # LocationChangeReply 메시지 생성
        location_change_reply_message = {
            "header": {
                "message_name": "Location_Change_Reply",
                "transaction_id": message['header']['transaction_id'],
                "system_key": "RTD"
            },
            "body": message['body'],
            "return": {
                "returncode": "2",
                "returnmessage": "fail"
            }
        }

        # MCSProducer 인스턴스 생성
        producer = MESProducer("config.json")
        producer.send_message(location_change_reply_message)
