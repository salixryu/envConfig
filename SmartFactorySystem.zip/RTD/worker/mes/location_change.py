from sqlalchemy import update, func
from sqlalchemy.orm import sessionmaker
from database.models import EquipmentUnit
from producer.mcs_producer import MCSProducer
from producer.mes_producer import MESProducer

class LocationChange:
    def __init__(self, engine):
        self.engine = engine
        self.Session = sessionmaker(bind=self.engine)

    def process(self, message):
        print("MES LocationChange received:")
        
        message_data = message
        body = message_data['body']
        equipment_unit_id = body['equipment_unit_id']
        location = body['location']

        try:
            session = self.Session()
            equipment_unit = session.query(EquipmentUnit).filter_by(EQUIPMENT_UNIT_ID=equipment_unit_id).first()
            
            if equipment_unit:
                equipment_unit.LOCATION = location
                # equipment_unit.UPDATED_TIME = func.current_timestamp()  # 현재 시간을 사용하여 업데이트
                session.commit()
                print(f"장비 유닛 ID '{equipment_unit_id}'의 위치가 '{location}'(으)로 업데이트되었습니다.")
            else:
                print(f"장비 유닛 ID '{equipment_unit_id}'에 해당하는 데이터를 찾을 수 없습니다.")
        except Exception as e:
            print("데이터베이스 업데이트 실패:", e)
        finally:
            session.close()

        mesSender = MESProducer("config.json")
        mesSender.send_message(message)
        # mesSender.return_tag("0", "sucess")
        # return_tag = {"returncode": "0", "returnmessage": "success"}
        # mesSender.send_reply_message(message)