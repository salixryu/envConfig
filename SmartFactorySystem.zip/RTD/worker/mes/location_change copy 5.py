import json
from entities.equipment_unit_vo import EquipmentUnitVO
from sqlalchemy import MetaData, Table, select

class LocationChange:
    def __init__(self, engine):
        # 외부에서 전달된 데이터베이스 연결 사용
        self.engine = engine

    def process(self, message):
        print("MES LocationChange received:")
        
        message_data = json.loads(message)
        body = message_data['body']
        equipment_unit_id = body['equipment_unit_id']

        # EQUIPMENT_UNIT_TB 테이블에서 데이터를 가져오는 쿼리 실행
        metadata = MetaData()
        equipment_unit_table = Table('EQUIPMENT_UNIT_TB', metadata, autoload=True, autoload_with=self.engine)
        query = select([equipment_unit_table]).where(equipment_unit_table.c.EQUIPMENT_UNIT_ID == equipment_unit_id)
        connection = self.engine.connect()
        result = connection.execute(query)
        row = result.fetchone()

        # 결과 출력
        if row:
            equipment_unit = EquipmentUnitVO(
                equipment_unit_id=row['EQUIPMENT_UNIT_ID'],
                equipment_unit_type=row['EQUIPMENT_UNIT_TYPE'],
                equipment_id=row['EQUIPMENT_ID'],
                carrier_id=row['CARRIER_ID'],
                location=row['LOCATION'],
                state=row['STATE'],
                previous_state=row['PREVIOUS_STATE'],
                action=row['ACTION'],
                previous_action=row['PREVIOUS_ACTION'],
                connection_state=row['CONNECTION_STATE'],
                created_time=row['CREATED_TIME'],
                updated_time=row['UPDATED_TIME'],
                modifier=row['MODIFIER']
            )
            print("Equipment Unit Data:")
            print(equipment_unit.__dict__)
        else:
            print("Equipment Unit not found.")
