import pika
import json

class MCSProducer:
    def __init__(self, config_file):
        with open(config_file) as f:
            config = json.load(f)
        
        rabbitmq_config = config['MCS']['rabbitmq']
        self.rabbitmq_host = rabbitmq_config['host']
        self.rabbitmq_port = rabbitmq_config['port']
        self.queue_name = config['MCS']['queue']['name']

    def send_message(self, message):
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=self.rabbitmq_host, port=self.rabbitmq_port))
        channel = connection.channel()

        channel.queue_declare(queue=self.queue_name)
        message['header']['system_key'] = "RTD"
        channel.basic_publish(exchange='', routing_key=self.queue_name, body=json.dumps(message))

        print("Message sent!")

        connection.close()

    def send_reply_message(self, message, return_tag):
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=self.rabbitmq_host, port=self.rabbitmq_port))
        channel = connection.channel()

        channel.queue_declare(queue=self.queue_name)
        message['header']['system_key'] = "RTD"
        message['header']['message_name'] = message['header']['message_name'] + '_Reply'
        message['return'] = return_tag  # return 정보 추가
        channel.basic_publish(exchange='', routing_key=self.queue_name, body=json.dumps(message))

        print("Reply message sent!")

        connection.close()
