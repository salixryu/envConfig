import pika
import json

class MESProducer:
    def __init__(self, config_file):
        with open(config_file) as f:
            config = json.load(f)
        
        rabbitmq_config = config['MES']['rabbitmq']
        self.rabbitmq_host = rabbitmq_config['host']
        self.rabbitmq_port = rabbitmq_config['port']
        self.queue_name = config['MES']['queue']['name']
        self.return_tag_data = None

    def return_tag(self, returncode, returnmessage):
        self.return_tag_data = {"returncode": returncode, "returnmessage": returnmessage}


    def send_message(self, message):
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=self.rabbitmq_host, port=self.rabbitmq_port))
        channel = connection.channel()

        channel.queue_declare(queue=self.queue_name)
        message['header']['system_key'] = "RTD"
        channel.basic_publish(exchange='', routing_key=self.queue_name, body=json.dumps(message))

        print("Message sent!")

        connection.close()

    def send_reply_message_para(self, message, return_tag):
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=self.rabbitmq_host, port=self.rabbitmq_port))
        channel = connection.channel()

        channel.queue_declare(queue=self.queue_name)
        message['header']['message_name'] = message['header']['message_name'] + 'Reply'
        message['header']['system_key'] = "RTD"
        message['return'] = return_tag  # return 정보 추가
        channel.basic_publish(exchange='', routing_key=self.queue_name, body=json.dumps(message))

        print("Reply message sent!")

        connection.close()

    def send_reply_message(self, message):
        if self.return_tag_data is None:
            raise ValueError("return_tag has not been set.")
        
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=self.rabbitmq_host, port=self.rabbitmq_port))
        channel = connection.channel()

        channel.queue_declare(queue=self.queue_name)
        message['header']['system_key'] = "RTD"
        message['header']['message_name'] = message['header']['message_name'] + '_Reply'
        message['return'] = self.return_tag_data  # 저장된 return_tag 데이터를 사용
        channel.basic_publish(exchange='', routing_key=self.queue_name, body=json.dumps(message))

        print("Reply message sent!")

        connection.close()