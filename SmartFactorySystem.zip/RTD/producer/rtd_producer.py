import pika
import json

class RTDProducer:
    def __init__(self, config_file):
        with open(config_file) as f:
            config = json.load(f)
        
        rabbitmq_config = config['RTD']['rabbitmq']
        self.rabbitmq_host = rabbitmq_config['host']
        self.rabbitmq_port = rabbitmq_config['port']
        self.queue_name = config['RTD']['queue']['name']

    def send_message(self, message):
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=self.rabbitmq_host, port=self.rabbitmq_port))
        channel = connection.channel()

        channel.queue_declare(queue=self.queue_name)

        channel.basic_publish(exchange='', routing_key=self.queue_name, body=json.dumps(message))

        print("Message sent!")

        connection.close()
