import importlib
import json

class MessageHandler:
    def __init__(self, engine):
        self.base_work_dir = "worker"
        self.engine = engine

    def process_message(self, message):
        message_data = json.loads(message)
        message_name = message_data['header']['message_name']
        system_id = message_data['header']['system_key'].lower()  # 시스템 식별자 소문자로 변환

        try:
            # 시스템 식별자에 따라 작업 디렉토리 설정
            system_work_dir = f"{self.base_work_dir}.{system_id}"

            # 클래스가 있는지 확인하고 동적으로 로딩하기
            module = importlib.import_module(f"{system_work_dir}.{message_name.lower()}")

            # 클래스 이름 가져오기
            class_name = message_name.replace('_', ' ').title().replace(' ', '')

            work_class = getattr(module, class_name)

            # 클래스 인스턴스 생성 및 메시지 처리
            work_instance = work_class(self.engine)
            work_instance.process(message_data)
        except KeyError:
            print("System ID is not provided in the message header.")
        except ImportError as e:
            print(f"No work found for message type {message_name}: {e}")
