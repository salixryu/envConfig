# equipment_unit_vo.py

class EquipmentUnitVO:
    def __init__(self, equipment_unit_id, equipment_unit_type, equipment_id, carrier_id, location, state, previous_state, action, previous_action, connection_state, created_time, modify_time, modifier):
        self.equipment_unit_id = equipment_unit_id
        self.equipment_unit_type = equipment_unit_type
        self.equipment_id = equipment_id
        self.carrier_id = carrier_id
        self.location = location
        self.state = state
        self.previous_state = previous_state
        self.action = action
        self.previous_action = previous_action
        self.connection_state = connection_state
        self.created_time = created_time
        self.modify_time = modify_time
        self.modifier = modifier

    # 다른 메서드들 추가 가능
