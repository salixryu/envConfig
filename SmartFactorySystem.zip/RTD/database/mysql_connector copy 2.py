import mysql.connector
import json

class MySQLConnector:
    def __init__(self, config_file):
        self.config_file = config_file
        self.load_config()

    def load_config(self):
        with open(self.config_file) as f:
            config = json.load(f)
            self.db_config = config['Database']['mysql']

    def connect(self):
        try:
            self.connection = mysql.connector.connect(
                host=self.db_config['host'],
                port=self.db_config['port'],
                database=self.db_config['database'],
                user=self.db_config['user'],
                password=self.db_config['password']
            )
            print("Connected to MySQL database")
        except mysql.connector.Error as e:
            print("Error connecting to MySQL database:", e)

    def close(self):
        if self.connection.is_connected():
            self.connection.close()
            print("MySQL connection closed")

# 예시 사용
if __name__ == "__main__":
    mysql_connector = MySQLConnector("config.json")
    mysql_connector.connect()
    # 여기서부터 데이터베이스 작업 수행
    # mysql_connector.close()를 호출하여 연결 종료
