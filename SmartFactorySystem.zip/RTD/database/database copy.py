# from sqlalchemy import create_engine, MetaData
# from sqlalchemy.orm import sessionmaker
# from sqlalchemy.ext.automap import automap_base

# # MySQL 연결 문자열
# connection_string = 'mysql+mysqlconnector://admin:1234@localhost:3306/rtd_db'

# # SQLAlchemy 엔진 생성
# engine = create_engine(connection_string)

# # 메타데이터 생성
# metadata = MetaData()

# # 기존 테이블 자동 매핑
# Base = automap_base()
# Base.prepare(engine, reflect=True)

# # EQUIPMENT_UNIT_TB 테이블 참조
# EquipmentUnitTB = Base.classes.EQUIPMENT_UNIT_TB

# class MyDatabaseClass:
#     def __init__(self):
#         # 세션 생성
#         Session = sessionmaker(bind=engine)
#         self.session = Session()

#     def get_equipment_unit_by_id(self, equipment_unit_id):
#         try:
#             # 쿼리 생성
#             query = self.session.query(EquipmentUnitTB).filter_by(EQUIPMENT_UNIT_ID=equipment_unit_id)

#             # 쿼리 실행
#             data = query.first()  # 결과에서 첫 번째 행 가져오기
#             return data
#         except Exception as e:
#             print("데이터 가져오기 실패:", e)
#             return None

# # 클래스 사용 예제
# my_db_class = MyDatabaseClass()
# equipment_unit_data = my_db_class.get_equipment_unit_by_id('unit005')
# if equipment_unit_data:
#     print("EQUIPMENT_UNIT_ID가 'unit005'인 데이터:", equipment_unit_data)
#     ID = equipment_unit_data.EQUIPMENT_UNIT_ID
#     equipment_unit_data
#     print(ID)
# else:
#     print("EQUIPMENT_UNIT_ID가 'unit005'인 데이터를 찾을 수 없습니다.")
