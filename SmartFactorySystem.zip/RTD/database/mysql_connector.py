# import json
# from sqlalchemy import create_engine

# def read_mysql_config(config_file):
#     with open(config_file, 'r') as f:
#         config_data = json.load(f)
#         mysql_config = config_data.get('Database', {}).get('mysql', {})
#     return mysql_config

# def create_mysql_connection_string(mysql_config):
#     username = mysql_config.get('user', '')
#     password = mysql_config.get('password', '')
#     host = mysql_config.get('host', 'localhost')
#     port = mysql_config.get('port', '3306')
#     database = mysql_config.get('database', '')

#     connection_string = f"mysql://{username}:{password}@{host}:{port}/{database}"
#     return connection_string

# def initialize_database(mysql_config):
#     connection_string = create_mysql_connection_string(mysql_config)
#     engine = create_engine(connection_string, echo=True)
#     # engine = create_engine(connection_string)
#     return engine
