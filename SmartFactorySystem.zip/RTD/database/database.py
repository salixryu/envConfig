from sqlalchemy import create_engine
import json

def initialize_engine(config_file):
    # JSON 파일에서 MySQL 연결 정보 가져오기
    with open(config_file) as f:
        config = json.load(f)
    
    mysql_config = config['RTD']['mysql']
    host = mysql_config['host']
    port = mysql_config['port']
    database = mysql_config['database']
    user = mysql_config['user']
    password = mysql_config['password']

    # 데이터베이스 연결 정보로부터 연결 문자열 생성
    connection_string = f'mysql+mysqlconnector://{user}:{password}@{host}:{port}/{database}'

    # DB engine 초기화
    engine = create_engine(connection_string)

    return engine
