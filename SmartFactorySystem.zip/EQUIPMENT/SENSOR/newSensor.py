import paho.mqtt.client as mqtt
import time
import random

def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    client.subscribe("temp/status")  # 해당 설비의 상태를 구독

def on_message(client, userdata, msg):
    print(msg.topic + " " + str(msg.payload))

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect("localhost", 1883, 60)

current_status = "23"  # 초기 상태를 On으로 설정

# 설비 상태 주기적으로 게시
while True:
    
    client.publish("temp/status", current_status)
    print("send Status:", current_status)  # 현재 상태를 게시
    time.sleep(3)
