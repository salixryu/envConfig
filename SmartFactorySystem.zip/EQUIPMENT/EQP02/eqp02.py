import paho.mqtt.client as mqtt
import time
import random
from datetime import datetime

def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    client.subscribe("eqp02/status")  # 해당 설비의 상태를 구독

def on_message(client, userdata, msg):
    log_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    print(f"{log_time} {msg.topic} {str(msg.payload)}")

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect("localhost", 1883, 60)

current_status = "On"  # 초기 상태를 On으로 설정

# 설비 상태 주기적으로 게시
while True:
    # 2% 확률로 상태 변경
    if random.random() < 0.01:
        current_status = "Off" if current_status == "On" else "On"
    
    client.publish("eqp02/status", current_status)
    log_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    print(f"{log_time} EQP02 Status: {current_status}")  # 현재 상태를 게시
    time.sleep(2)
