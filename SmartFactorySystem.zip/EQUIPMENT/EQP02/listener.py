import paho.mqtt.client as mqtt

# MQTT 브로커 정보
mqtt_host = "localhost"
mqtt_port = 1883
username = "guest"
password = "guest"

# 토픽
topic = "status/eqp02"

# 메시지를 받는 함수
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    client.subscribe(topic)

def on_message(client, userdata, msg):
    print("Received message: "+msg.payload.decode())

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.username_pw_set(username, password)
client.connect(mqtt_host, mqtt_port)
client.loop_forever()
