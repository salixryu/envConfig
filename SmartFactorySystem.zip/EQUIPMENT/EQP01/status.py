import pika
import json
import time
import random

class EquipmentB:
    def __init__(self, mqtt_host, mqtt_port, username, password):
        self.mqtt_host = mqtt_host
        self.mqtt_port = mqtt_port
        self.username = username
        self.password = password
        self.client = pika.BlockingConnection(pika.ConnectionParameters(host=mqtt_host, credentials=pika.PlainCredentials(username, password)))
        self.channel = self.client.channel()

        # Exchange 선언
        self.channel.exchange_declare(exchange='equipment_topic', exchange_type='topic')

    def report_status(self, status):
        message = {
            'equipment_id': "B",
            'status': status
        }
        self.channel.basic_publish(exchange='equipment_topic', routing_key='equipment.status', body=json.dumps(message))
        print(f"Sent status report: {status}")

    def start_reporting_status(self):
        # 시뮬레이션을 위한 임시 코드
        statuses = ['OK', 'ERROR', 'IDLE']
        while True:
            status = random.choice(statuses)
            print("Reporting status:", status)
            self.report_status(status)
            time.sleep(5)

if __name__ == "__main__":
    mqtt_host = "localhost"
    mqtt_port = 5672
    username = "guest"
    password = "guest"

    equipment_b = EquipmentB(mqtt_host, mqtt_port, username, password)
    equipment_b.start_reporting_status()
