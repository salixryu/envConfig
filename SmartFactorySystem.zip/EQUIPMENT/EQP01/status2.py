import paho.mqtt.client as mqtt
import json
import time
import random

class EquipmentB:
    def __init__(self, mqtt_host, mqtt_port, username, password):
        self.mqtt_host = mqtt_host
        self.mqtt_port = mqtt_port
        self.username = username
        self.password = password
        self.client = mqtt.Client()

        # 연결 이벤트 핸들러 설정
        self.client.on_connect = self.on_connect

        # MQTT 브로커에 연결
        self.client.username_pw_set(username=self.username, password=self.password)
        self.client.connect(self.mqtt_host, self.mqtt_port)

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT broker")
            # 연결되면 상태 메시지를 보내기 시작
            self.start_reporting_status()
        else:
            print("Failed to connect to MQTT broker")

    def report_status(self, status):
        message = {
            'equipment_id': "B",
            'status': status
        }
        self.client.publish("equipment/status", json.dumps(message))
        print(f"Sent status report: {status}")

    def start_reporting_status(self):
        # 시뮬레이션을 위한 임시 코드
        statuses = ['OK', 'ERROR', 'IDLE']
        while True:
            status = random.choice(statuses)
            print("Reporting status:", status)
            self.report_status(status)
            time.sleep(5)

if __name__ == "__main__":
    mqtt_host = "localhost"
    mqtt_port = 1883
    username = "guest"
    password = "guest"

    equipment_b = EquipmentB(mqtt_host, mqtt_port, username, password)
    equipment_b.client.loop_forever()
