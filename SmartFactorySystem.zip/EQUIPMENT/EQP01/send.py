import paho.mqtt.publish as publish

# MQTT 브로커 정보
mqtt_host = "localhost"
mqtt_port = 1883
username = "guest"
password = "guest"

# 토픽
topic = "status/eqp02"

# 테스트 메시지 발행
publish.single(topic, "Hello, MQTT!", hostname=mqtt_host, port=mqtt_port, auth={'username': username, 'password': password})
