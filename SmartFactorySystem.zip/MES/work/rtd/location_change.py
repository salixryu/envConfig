# location_change.py
class LocationChange:
    def process(self, message):
        print("RTD LocationChange received:")
