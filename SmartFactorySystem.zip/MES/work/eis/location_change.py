# location_change.py
class LocationChange:
    def process(self, message):
        print("EIS LocationChange received:")
        

