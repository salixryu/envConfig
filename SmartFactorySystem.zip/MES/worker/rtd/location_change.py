# location_change.py
class LocationChange:
    def __init__(self, engine):
        self.engine = engine
        # self.Session = sessionmaker(bind=self.engine)

    def process(self, message):
        print("RTD LocationChange received:", message)
