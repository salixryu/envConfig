# database/models.py
from sqlalchemy import Column, String, TIMESTAMP, Integer, DateTime, func, update
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class EquipmentUnit(Base):
    __tablename__ = 'EQUIPMENT_UNIT_TB'

    EQUIPMENT_UNIT_ID = Column(String(255), primary_key=True)
    EQUIPMENT_UNIT_TYPE = Column(String(255))
    EQUIPMENT_ID = Column(String(255))
    CARRIER_ID = Column(String(255))
    LOCATION = Column(String(255))
    STATE = Column(String(255))
    PREVIOUS_STATE = Column(String(255))
    ACTION = Column(String(255))
    PREVIOUS_ACTION = Column(String(255))
    CONNECTION_STATE = Column(String(255))
    CREATED_TIME = Column(TIMESTAMP, server_default=func.current_timestamp())
    MODIFY_TIME = Column(TIMESTAMP, server_default=func.current_timestamp(), onupdate=func.current_timestamp())
    MODIFIER = Column(String(255))
    # Define additional columns as needed

    def __repr__(self):
        return f"<EquipmentUnit(EQUIPMENT_UNIT_ID='{self.EQUIPMENT_UNIT_ID}', EQUIPMENT_UNIT_TYPE='{self.EQUIPMENT_UNIT_TYPE}')>"
