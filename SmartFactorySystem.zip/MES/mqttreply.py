import paho.mqtt.client as mqtt

# MQTT 브로커 정보
mqtt_host = "localhost"
mqtt_port = 1883
username = "guest"
password = "guest"

# 요청 및 응답 토픽
request_topic = "request/status"
response_topic = "response/status"

# 연결 완료 이벤트 핸들러
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    # 요청 수신 대기
    client.subscribe(request_topic)

# 메시지 수신 이벤트 핸들러
def on_message(client, userdata, msg):
    print("Received message: "+msg.payload.decode())
    # 요청 처리 및 응답 보내기
    if msg.payload.decode() == "What is your status?":
        client.publish(response_topic, "My status is ONLINE")

client = mqtt.Client()
client.username_pw_set(username, password)
client.on_connect = on_connect
client.on_message = on_message
client.connect(mqtt_host, mqtt_port)

# 백그라운드에서 메시지 루프 실행
client.loop_start()

# 연결 유지
while True:
    pass
