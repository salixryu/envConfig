import paho.mqtt.client as mqtt

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT broker")
    else:
        print("Connection failed")

broker_address = "localhost"  # 시스템 A와 동일한 브로커 주소를 사용합니다.
port = 1883
client = mqtt.Client()

client.on_connect = on_connect

client.connect(broker_address, port)
client.loop_forever()
