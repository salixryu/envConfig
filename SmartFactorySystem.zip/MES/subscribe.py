import paho.mqtt.publish as publish

# MQTT 브로커 정보
mqtt_host = "localhost"
mqtt_port = 1883
username = "guest"
password = "guest"

# 토픽 및 메시지
topic = "test/topic"
message = "Hello, MQTT!"

# MQTT 메시지 발행
publish.single(topic, message, hostname=mqtt_host, port=mqtt_port, auth={'username': username, 'password': password})

print("Message published")
