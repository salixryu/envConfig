# message_handler.py
import importlib
import json

class MessageHandler:
    def __init__(self):
        self.work_dir = "work"

    def process_message(self, message):
        message_data = json.loads(message)
        message_name = message_data['header']['message_name']
        self.execute_work(message_name, message_data)

    def execute_work(self, message_name, message_data):
        try:
            # 메시지 타입에 대응하는 클래스명 가져오기
            class_name = message_name.replace('_', ' ').title().replace(' ', '')
            # 스네이크 케이스 -> 퍼스널 케이스

            # 클래스가 있는지 확인하고 동적으로 로딩하기
            module = importlib.import_module(f"{self.work_dir}.{message_name.lower()}")

            work_class = getattr(module, class_name)

            # 클래스 인스턴스 생성 및 메시지 처리
            work_instance = work_class()
            work_instance.process(message_data)
        except ImportError as e:
            print(f"No work found for message type {message_name}: {e}")
