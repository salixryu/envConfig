# main.py
from consumer.mcs_consumer import MCSConsumer

if __name__ == "__main__":
    config_file = 'config.json'
    consumer = MCSConsumer(config_file)
    consumer.start_consuming()
