# mcs_consumer.py
import pika
import json
from handlers.message_handler import MessageHandler

class MCSConsumer:
    def __init__(self, config_file):
        with open(config_file) as f:
            config = json.load(f)
        
        rabbitmq_config = config['MCS']['rabbitmq']
        self.rabbitmq_host = rabbitmq_config['host']
        self.rabbitmq_port = rabbitmq_config['port']
        self.queue_name = config['MCS']['queue']['name']
        self.handler = MessageHandler()

    def callback(self, ch, method, properties, message):
        message_str = message.decode()  # 바이트를 문자열로 변환
        print("Received message:", json.dumps(json.loads(message_str), indent=2))  # 예쁘게 출력
        self.handler.process_message(message)

    def start_consuming(self):
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=self.rabbitmq_host, port=self.rabbitmq_port))
        channel = connection.channel()

        channel.queue_declare(queue=self.queue_name)
        channel.basic_consume(queue=self.queue_name, on_message_callback=self.callback, auto_ack=True)

        print('Waiting for messages. To exit press CTRL+C')
        channel.start_consuming()
