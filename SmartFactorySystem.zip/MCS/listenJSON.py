import pika
import json

def callback(ch, method, properties, body):
    message = json.loads(body)
    print(" [x] Received JSON message:", message)

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

channel.queue_declare(queue='json_queue')

channel.basic_consume(queue='json_queue', on_message_callback=callback, auto_ack=True)

print(' [*] Waiting for JSON messages. To exit press CTRL+C')
channel.start_consuming()
