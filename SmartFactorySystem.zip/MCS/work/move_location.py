# move_location.py
class MoveLocation:
    def process(self, message):
        print("MoveLocation received:", message)
