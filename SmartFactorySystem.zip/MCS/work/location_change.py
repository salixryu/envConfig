# location_change.py
from producer.rtd_producer import RTDProducer
class LocationChange:
    def process(self, message):
        print("LocationChange received:")

        rtdSender = RTDProducer("config.json")
        rtdSender.send_message(message)

