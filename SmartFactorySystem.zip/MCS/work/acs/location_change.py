from sqlalchemy import update, func
from sqlalchemy.orm import sessionmaker
from producer.rtd_producer import RTDProducer

class LocationChange:
    def __init__(self, engine):
        self.engine = engine
        self.Session = sessionmaker(bind=self.engine)

    def process(self, message):
        print("MES LocationChange received:")

        rtdSender = RTDProducer("config.json")
        rtdSender.send_message(message)
        # mesSender.return_tag("0", "sucess")
        # return_tag = {"returncode": "0", "returnmessage": "success"}
        # mesSender.send_reply_message(message)