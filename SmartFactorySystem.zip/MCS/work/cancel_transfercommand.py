# location_change.py
from producer.rtd_producer import RTDProducer
class CancelTransfercommand:
    def process(self, message):
        print("CancelTransfercommand received:")
        
        message_data = message
        body = message_data['body']
        commandId = body['commandId']

        print("Stop Transfercommand")
        print("CommandId: " + commandId)
        # rtdSender = RTDProducer("config.json")
        # rtdSender.send_message(message)

