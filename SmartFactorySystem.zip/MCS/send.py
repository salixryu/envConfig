import pika

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

channel.queue_declare(queue='hello')

channel.basic_publish(exchange='', routing_key='hello', body='Hello, RabbitMQ!')
print(" [x] Sent 'Hello, RabbitMQ!'")

connection.close()


# import pika

# # RabbitMQ 서버에 연결합니다
# connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
# channel = connection.channel()

# # 메시지를 보낼 큐의 이름을 지정합니다
# queue_name = 'hello'

# # 큐가 없다면 생성합니다
# channel.queue_declare(queue=queue_name)

# # 보낼 메시지를 작성합니다
# message = 'Hello, RabbitMQ!'

# # 메시지를 지정한 큐로 보냅니다
# channel.basic_publish(exchange='', routing_key=queue_name, body=message)
# print(" [x] Sent %r" % message)

# # 연결을 종료합니다
# connection.close()
