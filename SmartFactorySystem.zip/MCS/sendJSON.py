import pika
import json

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

channel.queue_declare(queue='json_queue')

message = {
    'key1': 'value11',
    'key2': 'value21',
    'key3': 'value31'
}

channel.basic_publish(exchange='', routing_key='json_queue', body=json.dumps(message))
print(" [x] Sent JSON message:", message)

connection.close()
